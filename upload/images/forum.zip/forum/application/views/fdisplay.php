<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="<?php echo base_url()?>css/styles.css" type="text/css" />
</head>
<body>
<div id="container">
	<div id="header">
    	<h1><a href="/">SIMPLE FORUM</a></h1>
        <h2></h2>
        <div class="clear"></div>
    </div>
    <div id="nav">
    <ul>
        	<li class="start"><a href="<?php echo base_url();?>home">Home</a></li>
            <?php
				if(!empty($forumDisplay)){
					foreach($forumDisplay as $row){ ?>
						<li><a href="<?php echo base_url();?>home/mforum/<?php echo $row->id ?>"><?php echo $row->nama ?></a></li>
					<?php
                    }
				}
			?>
            <li style="float:right"><a href="<?php echo base_url();?>home/user_add" href="#">+</a></li>
            <li style="float:right"><a href="<?php echo base_url();?>home/user_logout">User Logout</a></li>
            <li style="float:right"><a href="<?php echo base_url();?>home/user_login">User Login</a></li>
           
        </ul>
    </div>
    <div id="body">
		<div id="content">
        <a class="buttontread"  href="<?php echo base_url();?>home/createThread/<?php echo $id; ?>"> Buat Thread </a>
        
			<table class="tableforumFill">
            <?php
				if(!empty($forumDisplayFill)){
					foreach($forumDisplayFill as $data){ ?>
                    <tr>
                    	<td style="width:100px;border-right:1px solid #CCC"><img  style="height:150px;width:100px" src="<?php echo base_url() ?>images/avatar.png"></td>
					 	<td> 
                           <label class="judul"><a href="<?php echo base_url() ?>home\detailThread\<?php echo $data->idforum?>"><?php echo $data->judul?></a></label><br>
                           <label class="user"> Oleh <?php echo $data->nama ?></label> |   <label class="tanggal">  Di Post Tanggal <?php echo $data->tanggal?> </label>  <br> <br> 
                           <label class="isi"><?php echo $data->isi?></label>
                        </td>
                        </tr>
					<?php
                    }
				} else { ?>
						<tr>
                        	<td colspan="2"><center> Thread Belum Tersedia </center></td>
                        </tr>
				<?php }		
			?>
            </table>
            <a class="buttontread"  href="<?php echo base_url(); ?>home/createThread/<?php echo $id; ?>"> Buat Thread </a>
            <br>
        </div>
        
         
    	<div class="clear"></div>
    </div>
    <div id="footer">
        
        <div class="footer-bottom">
            <p>&copy; Copyleft 2013. <a href="http://treedesain.com/">Free Sourcode </a> by Aing</p>
         </div>
    </div>
</div>
</body>
</html>
