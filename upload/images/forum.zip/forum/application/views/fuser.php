<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="<?php echo base_url()?>css/styles.css" type="text/css" />
</head>
<body>
<div id="container">
	<div id="header">
    	<h1><a href="/">SIMPLE FORUM</a></h1>
        <h2></h2>
        <div class="clear"></div>
    </div>
    <div id="nav">
    	<ul>
        	<li class="start"><a href="<?php echo base_url();?>home">Home</a></li>
            <?php
				if(!empty($forumDisplay)){
					foreach($forumDisplay as $row){ ?>
						<li><a href="<?php echo base_url();?>home/mforum/<?php echo $row->id ?>"><?php echo $row->nama ?></a></li>
					<?php
                    }
				}
			?>
           <li style="float:right"><a href="<?php echo base_url();?>home/user_add" href="#">+</a></li>
            <li style="float:right"><a href="<?php echo base_url();?>home/user_logout">User Logout</a></li>
            <li style="float:right"><a href="<?php echo base_url();?>home/user_login">User Login</a></li>
        </ul>
    </div>
    <div id="body">
		<div id="content">
        
        	<?php if(!empty($flashdata)) {echo '<div class="flashdatax">'.$flashdata.'  </div>';} ?>
      
        <h2>LOGIN</h2>
        <form method="POST" name="frm" action="<?php echo base_url()?>home/cekuser">
            <table style="width:400px">
            	<tr>
                	<td  style="border-bottom:none">Username</td>
                	<td  style="border-bottom:none">:</td>
                	<td style="border-bottom:none"><input type="text" id="user" name="user"></td>
                </tr>
                <tr>
                	<td  style="border-bottom:none">Password</td>
                	<td  style="border-bottom:none">:</td>
                	<td style="border-bottom:none"><input type="text" id="pass" name="pass"></td>
                </tr>
                <tr>
                	<td> <input type="submit" value="Login" class="submitcomment"></td>
                    
                </tr>
            </table>
			</form>
        </div>
        
         
    	<div class="clear"></div>
    </div>
    <div id="footer">
        
        <div class="footer-bottom">
            <p>&copy; Copyleft 2013. <a href="http://treedesain.com/">Free Sourcode </a> by Aing</p>
         </div>
    </div>
</div>
</body>
</html>
